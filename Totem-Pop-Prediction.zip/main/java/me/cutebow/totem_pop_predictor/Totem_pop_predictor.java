package me.cutebow.totem_pop_predictor;

import net.fabricmc.api.ModInitializer;

public class Totem_pop_predictor implements ModInitializer {
    public static final String ID = "totem_pop_predictor";
    @Override
    public void onInitialize() { }
}
